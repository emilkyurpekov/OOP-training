package WorkingWithAbstraction.TrafficLighrts;

public enum Color {
    RED,
    GREEN,
    YELLOW;
}
